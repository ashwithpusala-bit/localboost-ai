import express from "express";
import OpenAI from "openai";
const app=express(); app.use(express.json());

const html=`<!doctype html><html lang="te"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>LocalBoost AI</title><style>
body{font-family:Arial;margin:0;background:#f4f6fb}.app{max-width:520px;margin:auto;background:#fff;min-height:100vh;padding:22px;box-sizing:border-box}
.card{padding:18px;border:1px solid #e5e7eb;border-radius:18px;margin:14px 0}input,select,button{width:100%;box-sizing:border-box;padding:13px;margin:7px 0;border-radius:11px;border:1px solid #d0d5dd;font-size:16px}button{background:#111827;color:#fff;font-weight:700}.out{white-space:pre-wrap;background:#f8fafc;padding:15px;border-radius:12px;line-height:1.55}
</style><div class=app><h1>LocalBoost AI 🚀</h1><p>Local Business Marketing Assistant</p>
<div class=card><input id=b placeholder="Business name"><input id=p placeholder="Product / service"><input id=pr placeholder="Price"><input id=o placeholder="Offer"><select id=l><option>Telugu</option><option>English</option></select><button onclick=go()>✨ Generate My Ad</button></div>
<div class=card id=r style="display:none"><h2>AI Marketing Pack</h2><div id=x class=out></div></div></div>
<script>async function go(){const x=document.getElementById("x");document.getElementById("r").style.display="block";x.textContent="Generating...";try{const z=await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({business:b.value,product:p.value,price:pr.value,offer:o.value,language:l.value})});const j=await z.json();x.textContent=j.text||j.error||"Something went wrong"}catch(e){x.textContent="Server connection error"}}</script>`;

app.get("/",(q,s)=>s.send(html));
app.post("/api/generate",async(q,s)=>{
 try{
  if(!process.env.OPENAI_API_KEY)return s.status(500).json({error:"OpenAI API key is not configured."});
  const {business,product,price,offer,language="Telugu"}=q.body;
  const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
  const r=await client.responses.create({model:"gpt-5-mini",input:`You are a marketing assistant for a local Indian business. Create a marketing pack in ${language}. Business: ${business}. Product/service: ${product}. Price: ${price}. Offer: ${offer}. Return exactly three sections: ADVERTISEMENT, INSTAGRAM CAPTION, WHATSAPP STATUS. Use natural attractive Telugu when Telugu is selected. Do not invent phone numbers, addresses, guarantees, or facts.`});
  s.json({text:r.output_text});
 }catch(e){console.error(e);s.status(500).json({error:"AI generation failed. Check the server/API key."})}
});
app.listen(process.env.PORT||3000,()=>console.log("LocalBoost AI running"));
