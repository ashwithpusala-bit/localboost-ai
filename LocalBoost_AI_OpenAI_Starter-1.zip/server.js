import express from "express";
import OpenAI from "openai";
import path from "path";
import {fileURLToPath} from "url";

const app=express();
const __dirname=path.dirname(fileURLToPath(import.meta.url));
app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));

app.post("/api/generate", async (req,res)=>{
  try{
    if(!process.env.OPENAI_API_KEY) return res.status(500).json({error:"OPENAI_API_KEY is not configured on the server."});
    const {business,product,price,offer,language="Telugu"}=req.body;
    const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const response=await client.responses.create({
      model:"gpt-5-mini",
      input:`You are a marketing assistant for a local Indian business.
Create a marketing pack in ${language}.
Business: ${business}
Product/service: ${product}
Price: ${price}
Offer: ${offer}
Return exactly three sections: ADVERTISEMENT, INSTAGRAM CAPTION, WHATSAPP STATUS.
Use natural, attractive Telugu when Telugu is selected. Do not invent phone numbers, addresses, guarantees, or facts.`
    });
    res.json({text:response.output_text});
  }catch(e){res.status(500).json({error:"AI generation failed."});}
});
app.listen(process.env.PORT||3000,()=>console.log("LocalBoost AI running"));
