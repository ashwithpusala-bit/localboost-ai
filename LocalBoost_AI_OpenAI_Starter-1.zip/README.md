# LocalBoost AI
OpenAI-powered local business marketing demo.

## Important
Never put the API key inside `public/index.html` or share it in chat.
Set `OPENAI_API_KEY` as a server environment variable.

## Run
npm install
OPENAI_API_KEY="your-key" npm start
Then open http://localhost:3000

For production, deploy the Node server to a trusted host and add the secret as an environment variable.
